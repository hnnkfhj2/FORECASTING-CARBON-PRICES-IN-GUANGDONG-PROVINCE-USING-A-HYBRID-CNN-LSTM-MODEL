
import os
from pprint import pprint
import tensorflow as tf
import numpy as np
import pandas as pd
from keras.layers import LSTM, Conv1D, Dense, MaxPooling1D
from keras.metrics import RootMeanSquaredError
from keras.models import Sequential, load_model
from keras.optimizers import Adam
from sklearn.metrics import (mean_absolute_error,
                             mean_absolute_percentage_error,
                             mean_squared_error)
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import TimeSeriesSplit
from utils import (indicator_append, plot_metrics_val,
                   plot_price_test_prediction, plot_test_prediction,
                   rolling_window, save_loss, save_model)

import pandas_ta  # isort:skip

def cnn_lstm(n_timesteps, n_features):

    model = Sequential()

    model.add(
        Conv1D(
            64,
            1,
            padding="same",
            activation="tanh",
            input_shape=(n_timesteps, n_features),
        )
    )
    model.add(MaxPooling1D(1, padding="same"))
    # model.add(AveragePooling1D(pool_size=2, strides=2, padding='same'))

    model.add(LSTM(64))
    # model.add(Flatten())
    model.add(Dense(1))

    model.compile(
        optimizer=Adam(learning_rate=0.00005),
        loss="mse",
        metrics=[RootMeanSquaredError(), "mse", "mae", "mape"],
    )
    return model


def qlike_loss(y_true, y_pred):
    return tf.reduce_sum((y_true / y_pred - tf.math.log(y_true / y_pred) - 1))


def main():
    # ticker = "Combined_GUANGDONG_BrentOil"
    ticker = "data2017_cleaned"
    df = pd.read_csv(f"data/{ticker}.csv", index_col="Date", parse_dates=True)
    df = indicator_append(df)
    print(df.head())

    scaler = MinMaxScaler()
    scaler_close = MinMaxScaler()
    df_scaled = scaler.fit_transform(df)
    scaler_close.fit(df["Close"].to_numpy().reshape(-1, 1))

    window_size = 10
    target_col = df.columns.to_list().index("Close")
    df = df.reset_index(drop=True)

    x, y = rolling_window(df_scaled, window_size, target_col)

    tscv = TimeSeriesSplit(n_splits=2,test_size=200)
    fold_idx = 1
    test_mse=[]
    test_rmse=[]
    test_mae=[]
    test_mape=[]
    test_qlike = []

    for i in range(1):
        for train_index, test_index in tscv.split(x):
            x_train, x_test = x[train_index], x[test_index]
            y_train, y_test = y[train_index], y[test_index]

            n_timesteps = x_train.shape[1]
            n_features = x_train.shape[-1]

            model = cnn_lstm(n_timesteps, n_features)
            print(f"Training fold {fold_idx} with {len(train_index)} train instances and {len(test_index)} test instances")
            history = model.fit(
                x_train,
                y_train,
                validation_data=(x_test, y_test),
                epochs=100,
                verbose=1
            )

            fold_idx += 1

            prediction = model.predict(x_test)
            test_mse.append(mean_squared_error(scaler_close.inverse_transform(y_test.reshape(-1, 1)),
                                          scaler_close.inverse_transform(prediction.reshape(-1, 1))))
            test_mae.append(mean_absolute_error(scaler_close.inverse_transform(y_test.reshape(-1, 1)),
                                           scaler_close.inverse_transform(prediction.reshape(-1, 1))))
            test_mape.append(mean_absolute_percentage_error(scaler_close.inverse_transform(y_test.reshape(-1, 1)),
                                                       scaler_close.inverse_transform(prediction.reshape(-1, 1))))
            ##########################################qlike
            y_test_rescaled = scaler_close.inverse_transform(y_test.reshape(-1, 1))
            prediction_rescaled = scaler_close.inverse_transform(prediction.reshape(-1, 1))
            qlike_value = qlike_loss(y_test_rescaled, prediction_rescaled).numpy()  # 使用 numpy() 获取张量的值
            test_qlike.append(qlike_value)
    ###########

    ###########
    mean_mse = np.mean(test_mse)
    mean_rmse=np.sqrt(test_mse)
    mean_rmse_mae = np.mean(test_mae)
    test_mape = np.mean(test_mape)
    mean_qlike=np.mean(test_qlike)
    print(f"MSE: {test_mse}, RMSE: {test_rmse}, MAE: {test_mae}, MAPE: {test_mape}")
###################################
    # model_name = save_model(model, __file__, ticker)
    # saved_model = load_model(model_name)###save?
    loss = {
        "train": {
            "MSE": history.history["loss"][-1],
            "RMSE": history.history["root_mean_squared_error"][-1],
            "MAE": history.history["mae"][-1],
            "MAPE": history.history["mape"][-1],
        },
        "test": {
            "MSE": test_mse,
            "RMSE": test_rmse,
            "MAE": mean_absolute_error(y_test, prediction),
            "MAPE": mean_absolute_percentage_error(y_test, prediction),
        },
    }
    # save_loss({"test": {"MSE": test_mse, "RMSE": test_rmse, "MAE": test_mae, "MAPE": test_mape}}, __file__, ticker)
    save_loss(loss, __file__, ticker)
    pprint(f"Model and loss saved for ticker {ticker}")

    # x_train, x_test, y_train, y_test = train_test_split(
    #     x, y, test_size=0.2, shuffle=False
    # )
    #
    # n_timesteps = x_train.shape[1]
    # n_features = x_train.shape[-1]
    #
    # model = cnn_lstm(n_timesteps, n_features)
    # print(f"train model <{'-' * 80 }")
    # history = model.fit(
    #     x_train,
    #     y_train,
    #     validation_data=(x_test, y_test),
    #     epochs=100,
    #     verbose=1,
    #     # shuffle=True,
    # )
    #
    # print(f"prediction <{'-' * 80}")
    # prediction = model.predict(x_test)
    #
    # test_mse = mean_squared_error(y_test, prediction)
    # test_rmse = np.sqrt(test_mse)
    # loss = {
    #     "train": {
    #         "MSE": history.history["loss"][-1],
    #         "RMSE": history.history["root_mean_squared_error"][-1],
    #         "MAE": history.history["mae"][-1],
    #         "MAPE": history.history["mape"][-1],
    #     },
    #     "test": {
    #         "MSE": test_mse,
    #         "RMSE": test_rmse,
    #         "MAE": mean_absolute_error(y_test, prediction),
    #         "MAPE": mean_absolute_percentage_error(y_test, prediction),
    #     },
    # }
    #
    model_name = save_model(model, __file__, ticker)
    saved_model = load_model(model_name)
    # save_loss(loss, __file__, ticker)
    #
    # model.evaluate(x_test, y_test)
    # pprint(loss)
    # model.summary()
    #
    fname = os.path.basename(__file__)
    fname = os.path.splitext(fname)[0]
    plot_metrics_val(
        history,
        "root_mean_squared_error",
        "loss",
        "mae",
        __file__,
        ticker=ticker,
        title="lstm",
    )
    # # plot_model(
    # #     model,
    # #     to_file=f"report/{fname}-plot.png",
    # #     show_shapes=True,
    # #     show_layer_names=False,
    # #     dpi=200,
    # # )
    plot_price_test_prediction(
        df["Close"],
        scaler_close.inverse_transform(y_test[:, None]),
        scaler_close.inverse_transform(prediction),
        df.index,
        window_size,
        fname=__file__,
        ticker=ticker,
        title="lstm",
    )
    # plot_test_prediction(
    #     scaler_close.inverse_transform(y_test[:, None]),
    #     scaler_close.inverse_transform(prediction),
    #     fname=__file__,
    #     ticker=ticker,
    #     title="lstm",
    # )


if __name__ == "__main__":
    main()
